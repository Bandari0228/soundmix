// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAN0TU0ts6gfVRFHVIL86Y0Lmoziiuvef8",
  authDomain: "music-app-54e7a.firebaseapp.com",
  projectId: "music-app-54e7a",
  storageBucket: "music-app-54e7a.appspot.com",
  messagingSenderId: "683771726708",
  appId: "1:683771726708:web:1cfdaa861952d4c702ba21"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export  default app;
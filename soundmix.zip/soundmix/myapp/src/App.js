
import React from "react";
import {BrowserRouter as Router,Routes, Route } from "react-router-dom";
import './App.css';
import Homepage from "./components/home";
import Login from "./components/login";
import Signup from "./components/signup";
import Soundmix from "./components/soundmix";
function App() {
  return (
    <>
    <Router>
      <Routes>
        <Route exact path="/" element={<Homepage />} />
        <Route exact path="/soundmix" element={<Soundmix />} />
        <Route exact path="/login" element={<Login />} />
        <Route exact path="/signup" element={<Signup />} />
      </Routes>
    </Router>
    </>
  );
}

export default App;

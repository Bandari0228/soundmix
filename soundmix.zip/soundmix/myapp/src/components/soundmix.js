import { useEffect, useState } from "react";
import React from 'react'

const Soundmix=()=> {
    const [keyword, setkeyword] = useState("");
    const [isloading, setisloading] = useState(true);
    const [tracks, settracks] = useState([]);
    const gettracks = async () => {
      setisloading(true);
      let data = await fetch(
        `https://v1.nocodeapi.com/harish2/spotify/yvKnhsjAgXTZsJNj/search?q=${keyword === "" ? "trending" : keyword}&type=track`
      );

      // https://v1.nocodeapi.com/harish2/spotify/yvKnhsjAgXTZsJNj/search?q=songs&type=track
      let convertedata = await data.json();
      console.log(convertedata.tracks.items);
  
      settracks(convertedata.tracks.items);
      setisloading(false);
    };
  
    useEffect(() => {
      gettracks();
    }, []);
  



  return (
   <>
    
    <nav className="navbar navbar-dark  navbar-expand-lg bg-dark">
        <div className="container-fluid">
          <a className="navbar-brand" href="/">
            Soundmix
          </a>
          {/* <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon" />
          </button> */}
          <div
            className="collapse navbar-collapse d-flex justify-content-center"
            id="navbarSupportedContent"
          >
            <input
              value={keyword}
              onChange={(event) => {
                setkeyword(event.target.value);
              }}
              className="form-control me-2 w-75"
              type="search"
              placeholder="Search"
              aria-label="Search"
            />
            <button onClick={gettracks} className="btn btn-outline-success">
              Search
            </button>
          </div>
        </div>
      </nav>

      <div className="container">
        <div className={`row ${isloading ? "" : "d-none"}`}>
          <div className="col-12 py-5 text-center">
            <div
              className="spinner-border"
              style={{ width: "3rem", height: "3rem" }}
              role="status"
            >
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        </div>
        
        <div className="row">
          {tracks.map((element) => {
            return (
              <div key={element.id} className="col-lg-3 col-md-4 py-2">
                <div className="card">
                  <img
                    src={element.album.images[0].url}
                    className="card-img-top"
                    alt="..."
                  />
                  <div className="card-body">
                    <h5 className="card-title">{element.name}</h5>
                    <p className="card-text">
                      Artist: {element.album.artists[0].name}
                    </p>
                    <p className="card-text">
                      Release Date: {element.album.release_date}
                    </p>
                    <audio
                      src={element.preview_url}
                      controls
                      className="w-100"
                    ></audio>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>      

   </>
  )
}
export default Soundmix;